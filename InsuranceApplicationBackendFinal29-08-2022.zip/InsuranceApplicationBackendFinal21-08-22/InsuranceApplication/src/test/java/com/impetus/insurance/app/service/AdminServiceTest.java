package com.impetus.insurance.app.service;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import com.impetus.insurance.app.entity.Admin;
import com.impetus.insurance.app.entity.PasswordEncrypt;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.AdminRepository;
import com.impetus.insurance.app.service.impl.AdminService;

@SpringBootTest
class AdminServiceTest {

	@InjectMocks
	AdminService adminServiceObject;

	@Mock
	AdminRepository adminRepo;

	@Mock
	Admin admin;

	@BeforeEach
	void setUp() throws Exception {

		admin = new Admin();
		admin.setId(1);
		admin.setEmail("deeksha@gmail.com");
		admin.setPassword(PasswordEncrypt.EncryptPass("XD"));
	}

	@Test
	void testCreateNewAccount() {
		when(adminRepo.save(admin)).thenReturn(admin);
		adminServiceObject.createNewAcccount(admin);
		verify(adminRepo, times(1)).save(admin);
		assertNotNull(admin, "Not null");
	}

	@Test
	void testCreateNewAccount1() {
		Admin aObj = null;
		when(adminRepo.save(aObj)).thenReturn(null);
		adminServiceObject.createNewAcccount(aObj);
		verify(adminRepo, times(1)).save(aObj);
		assertNull(aObj);
	}

	@Test
	void testValidateLogin() throws InvalidCredentialsException {

		Admin dummyUser = new Admin();
		dummyUser.setId(1);
		dummyUser.setEmail("deeksha@gmail.com");
		dummyUser.setPassword("XD");

		// passed when user tries to login
		when(adminRepo.existsByEmail(dummyUser.getEmail())).thenReturn(true);
		when(adminRepo.findByEmail(dummyUser.getEmail())).thenReturn(admin);
		String x = PasswordEncrypt.EncryptPass(dummyUser.getPassword());
		assertEquals(true, x.equals(admin.getPassword()));
		when(adminServiceObject.validateLogin(dummyUser)).thenReturn(admin);

	}

	@Test
	void testValidateLogin1() throws InvalidCredentialsException {

		Admin dummyUser = new Admin();
		dummyUser.setId(1);
		dummyUser.setEmail("deeksha@gmail.com");
		dummyUser.setPassword("XD");

		when(adminRepo.existsByEmail(dummyUser.getEmail())).thenReturn(false);
		assertThrows(InvalidCredentialsException.class, () -> adminServiceObject.validateLogin(dummyUser));

	}

	@Test
	void testValidateLogin2() throws InvalidCredentialsException {

		Admin dummyUser = new Admin();
		dummyUser.setId(1);
		dummyUser.setEmail("deeksha@gmail.com");
		dummyUser.setPassword("XDfgfhtffh");

		when(adminRepo.existsByEmail(dummyUser.getEmail())).thenReturn(true);
		when(adminRepo.findByEmail(admin.getEmail())).thenReturn(admin);
		assertNotEquals(true, admin.getPassword().equals(dummyUser.getPassword()));
		assertThrows(InvalidCredentialsException.class, () -> adminServiceObject.validateLogin(dummyUser));

	}

}
