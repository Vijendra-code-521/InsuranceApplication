package com.impetus.insurance.app.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.impetus.insurance.app.entity.Policy;
import com.impetus.insurance.app.entity.UserPolicyState;
import com.impetus.insurance.app.exceptions.InvalidPolicyIdException;
import com.impetus.insurance.app.repository.PolicyRepository;
import com.impetus.insurance.app.repository.UserPolicyStateRepository;
import com.impetus.insurance.app.service.impl.PolicyService;

@SpringBootTest
class PolicyServiceTest {

	@InjectMocks
	PolicyService policyServiceObject;

	@Mock
	UserPolicyStateRepository uspRepo;

	@Mock
	PolicyRepository policyRepo;

	Policy policy;
	UserPolicyState reqObject;

	@BeforeEach
	void setUpObjects() {

		policy = new Policy();
		policy.setId(1);
		policy.setLifeCover(new int[] { 500, 400, 300, 200, 100, 90, 80 });
		policy.setDescription("LIC");
		policy.setCoverFor(new int[] { 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30, 25, 20, 15 });
		policy.setModeOfPp(new String[] { "One-time", "Monthly", "Yearly" });
		policy.setName("Sampoorna Raksha");
		policy.setPayFor(new int[] { 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 });
		policy.setTypeOfPolicy("life");

	}

	@Test
	void add() {
		policyServiceObject.add(policy);
		policyRepo.save(policy);
		verify(policyRepo, times(2)).save(policy);
		assertNotNull(policy, "Not null");
	}

	@Test
	void remove() throws InvalidPolicyIdException {
		policyServiceObject.remove(1);
		policyRepo.deleteById(1);
		doNothing().when(policyRepo).deleteById(1);
		verify(policyRepo, times(2)).deleteById(1);
	}

	@Test
	void remove2() throws InvalidPolicyIdException {
		List<UserPolicyState> plist = new ArrayList<UserPolicyState>();
		plist.add(reqObject);
		doReturn(plist).when(uspRepo).findAllByPolicyId(100);
		assertEquals(false, plist.isEmpty());
		assertThrows(InvalidPolicyIdException.class, () -> policyServiceObject.remove(100));
	}

	@Test
	void viewAllPolicies() {

		List<Policy> listPolicy = new ArrayList<Policy>();
		listPolicy.add(policy);

		when(policyRepo.findAll()).thenReturn(listPolicy);
		policyServiceObject.viewAll();
		policyRepo.findAll();
		verify(policyRepo, times(2)).findAll();

	}

	@Test
	void viewPolicy() throws InvalidPolicyIdException {
		assertThrows(InvalidPolicyIdException.class, () -> policyServiceObject.viewById(1));
	}

	@Test
	void viewPolicy1() throws InvalidPolicyIdException {
		Optional<Policy> optinalobj;
		optinalobj = Optional.of(policy);
		when(policyRepo.findById(1)).thenReturn(optinalobj);
		policyServiceObject.viewById(1);
		assertNotNull(policy, "Not null");
	}

	@Test
	void edit() throws InvalidPolicyIdException {
		Optional<Policy> optinalobj;
		optinalobj = Optional.of(policy);
		when(policyRepo.findById(1)).thenReturn(optinalobj);
		policyServiceObject.edit(1, policy);
	}
}
