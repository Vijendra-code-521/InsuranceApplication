package com.impetus.insurance.app.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.impetus.insurance.app.entity.Nominee;
import com.impetus.insurance.app.entity.Policy;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.entity.UserPolicyState;
import com.impetus.insurance.app.entity.UserPolicyStateDto;
import com.impetus.insurance.app.repository.NomineeRepository;
import com.impetus.insurance.app.repository.PolicyRepository;
import com.impetus.insurance.app.repository.UserPolicyStateRepository;
import com.impetus.insurance.app.repository.UserRepository;
import com.impetus.insurance.app.service.impl.UserPolicyStateService;

@SpringBootTest
class UserPolicyStateServiceTest {

	@InjectMocks
	UserPolicyStateService uspService;

	@Mock
	UserPolicyStateRepository uspRepo;

	@Mock
	PolicyRepository policyRepo;

	@Mock
	NomineeRepository nomineeRepo;

	@Mock
	UserRepository userRepo;
	
	UserPolicyState reqObject;
	Nominee nominee;
	Policy policy;
	UserPolicyStateDto uspObject;
	User user;

	@BeforeEach
	void setUpObjects() {

		nominee = new Nominee();
		nominee.setId(1);
		nominee.setFirstName("Deeksha");
		nominee.setLastName("Patidar");
		nominee.setPhone(234566792);
		nominee.setAadharNo(1234456778);
		nominee.setRelation("Mother");

		user = new User();
		user.setId(1);
		user.setFirstName("D");
		user.setLastName("P");
		user.setAge(13);
		user.setCity("Indore");
		user.setEducation("BBA");
		user.setEmail("dp@gmail.com");
		user.setGender("Female");
		user.setIncome("500000");
		Date d = new Date();
		d.setDate(20001);
		user.setDob(d);
		user.setIsSmoker(true);

		policy = new Policy();
		policy.setId(1);
		policy.setLifeCover(new int[] { 500, 400, 300, 200, 100, 90, 80 });
		policy.setDescription("LIC");
		policy.setCoverFor(new int[] { 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30, 25, 20, 15 });
		policy.setModeOfPp(new String[] { "One-time", "Monthly", "Yearly" });
		policy.setName("Sampoorna Raksha");
		policy.setPayFor(new int[] { 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 });
		policy.setTypeOfPolicy("life");

		uspObject = new UserPolicyStateDto();
		uspObject.setId(1);
		uspObject.setNominee(5);
		uspObject.setOwner(3);
		uspObject.setPolicy(2);
		uspObject.setPremium(1235243);
		uspObject.setStatus("PENDING");
		uspObject.setSummary("Life cover : xyz");
		Date date = new Date();
		Timestamp ts = new Timestamp(date.getTime());
		uspObject.setTs(ts);

		reqObject = new UserPolicyState();
		reqObject.setId(1);
		reqObject.setNominee(nominee);
		reqObject.setOwner(user);
		reqObject.setPolicy(policy);
		reqObject.setPremium(1235243);
		reqObject.setStatus("PENDING");
		reqObject.setSummary("Life cover : xyz");
		Date date1 = new Date();
		Timestamp ts1 = new Timestamp(date1.getTime());
		reqObject.setTs(ts1);

	}

	@Test
	void addTest() {
		when(nomineeRepo.findById(1)).thenReturn(Optional.of(nominee));
		when(policyRepo.findById(1)).thenReturn(Optional.of(policy));
		when(userRepo.findById(1)).thenReturn(Optional.of(user));
		uspService.add(uspObject);
		uspRepo.save(reqObject);
		verify(uspRepo, times(1)).save(reqObject);
		assertNotNull(reqObject, "Not null");
	}

	@Test
	void updateTest() {
		Optional<UserPolicyState> optinalobj;
		optinalobj = Optional.of(reqObject);
		when(uspRepo.findById(1)).thenReturn(optinalobj);
		uspService.update(1, reqObject);
	}

	@Test
	void viewByIdTest() {
		Optional<UserPolicyState> optinalobj;
		optinalobj = Optional.of(reqObject);
		when(uspRepo.findById(1)).thenReturn(optinalobj);
		uspService.viewById(1);
		assertNotNull(reqObject, "Not null");
	}

	@Test
	void viewAllPoliciesTest() {

		List<UserPolicyState> listPolicy = new ArrayList<UserPolicyState>();
		listPolicy.add(reqObject);

		when(uspRepo.findAll()).thenReturn(listPolicy);
		uspService.getAll();
		uspRepo.findAll();
		verify(uspRepo, times(2)).findAll();
	}

	@Test
	void getRequestObjectByStatusTest() {

		List<UserPolicyState> listPolicy = new ArrayList<UserPolicyState>();
		listPolicy.add(reqObject);

		when(uspRepo.findAllByStatus("PENDING")).thenReturn(listPolicy);
		uspService.getRequestObjectByStatus("PENDING");
		uspRepo.findAllByStatus("PENDING");
		verify(uspRepo, times(2)).findAllByStatus("PENDING");
	}

	@Test
	void getMyPoliciesTest() {

		List<UserPolicyState> listPolicy = new ArrayList<UserPolicyState>();
		listPolicy.add(reqObject);

		when(uspRepo.findAllByOwnerId(1)).thenReturn(listPolicy);
		uspService.getMyPolicies(1);
		uspRepo.findAllByOwnerId(1);
		verify(uspRepo, times(2)).findAllByOwnerId(1);
	}

}
