package com.impetus.insurance.app.rest.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.impetus.insurance.app.entity.UserPolicyState;
import com.impetus.insurance.app.entity.UserPolicyStateDto;
import com.impetus.insurance.app.service.impl.UserPolicyStateService;

/**
 * This rest controller handles all the api calls for insurance request.
 * 
 * @author deeksha.patidar
 * @version 1.0
 */
@RestController
@RequestMapping("/api/v1/")
public class InsuranceRequestController {

	@Autowired
	UserPolicyStateService uspService;

	/**
	 * This method is post insurance request api, adds new insurance request
	 * 
	 * @param object
	 * @return HttpStatus
	 */
	@PostMapping("requestObject")
	public ResponseEntity<HttpStatus> add(@RequestBody UserPolicyStateDto object) {
		uspService.add(object);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	/**
	 * This method is get insurance request api, gets all insurance policies
	 * purchased by a user
	 * 
	 * @param id
	 * @return List of UserPolicyState
	 */
	@GetMapping("requestObject/user/{id}")
	public ResponseEntity<List<UserPolicyState>> getMyPolicies(@PathVariable("id") int id) {
		return new ResponseEntity<>(uspService.getMyPolicies(id), HttpStatus.OK);
	}

	/**
	 * This method is get insurance request api, gets insurance request object by id
	 * 
	 * @param id
	 * @return UserPolicyState object
	 */
	@GetMapping("requestObject/{id}")
	public ResponseEntity<UserPolicyState> getRequestObject(@PathVariable("id") int id) {
		return new ResponseEntity<>(uspService.viewById(id), HttpStatus.OK);
	}

	/**
	 * This method is get insurance request api, gets all the insurance request
	 * objects of a given status
	 * 
	 * @param status
	 * @return List of UserPolicyState
	 */
	@GetMapping("requestObject/all/{status}")
	public ResponseEntity<List<UserPolicyState>> getRequestObjectByStatus(@PathVariable("status") String status) {
		return new ResponseEntity<>(uspService.getRequestObjectByStatus(status), HttpStatus.OK);
	}

	/**
	 * This method is get insurance request api, gets all insurance request objects
	 * 
	 * @return List of UserPolicyState
	 */
	@GetMapping("requestObject")
	public ResponseEntity<List<UserPolicyState>> getAll() {
		return new ResponseEntity<>(uspService.getAll(), HttpStatus.OK);
	}

	/**
	 * This method is post insurance request api, updates insurance request object
	 * 
	 * @param object
	 * @return HttpStatus
	 */
	@PostMapping("requestObject/update")
	public ResponseEntity<HttpStatus> updateRequestObj(@RequestBody @Valid UserPolicyState object) {
		uspService.update(object.getId(), object);
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
	}

}
