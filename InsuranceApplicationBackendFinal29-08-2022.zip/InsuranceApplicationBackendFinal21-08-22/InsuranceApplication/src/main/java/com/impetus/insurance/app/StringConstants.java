package com.impetus.insurance.app;


/**
 * Contains all string constants used in the application.
 * 
 * @author deeksha.patidar
 *
 */
public class StringConstants {

	private StringConstants() {

	}

	public static final String APPROVED = "APPROVED";
	public static final String PENDING = "PENDING";
	public static final String REJECTED = "REJECTED";
	public static final String AWAITING = "AWAITING";
	public static final String MONTHLY = "MONTHLY";
	public static final String ONETIME = "ONETIME";
	public static final String YEARLY = "YEARLY";
}
