package com.impetus.insurance.app.entity;

import java.sql.Timestamp;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the UserPolicyStateDto.
 * 
 * @author deeksha.patidar
 *
 */
@Getter
@Setter
@ToString
public class UserPolicyStateDto {

	/**
	 * int value for primary key
	 */
	int id;

	/**
	 * long value for premium
	 */
	long premium;

	/**
	 * int value for primary key
	 */
	int nominee;

	/**
	 * int value for primary key
	 */
	int owner;

	/**
	 * int value for primary key
	 */
	int policy;

	/**
	 * string value for summary
	 */
	String summary;

	/**
	 * Timestamp value
	 */
	Timestamp ts;

	/**
	 * string value for status
	 */
	String status;

	/**
	 * Default Constructor
	 */
	public UserPolicyStateDto() {

	}

	/**
	 * Parameterised Constructor
	 * 
	 * @param id
	 * @param premium
	 * @param nominee
	 * @param owner
	 * @param policy
	 * @param summary
	 * @param ts
	 * @param status
	 */
	public UserPolicyStateDto(int id, long premium, int nominee, int owner, int policy, String summary, Timestamp ts,
			String status) {
		super();
		this.id = id;
		this.premium = premium;
		this.nominee = nominee;
		this.owner = owner;
		this.policy = policy;
		this.summary = summary;
		this.ts = ts;
		this.status = status;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getPremium() {
		return premium;
	}

	public void setPremium(long premium) {
		this.premium = premium;
	}

	public int getNominee() {
		return nominee;
	}

	public void setNominee(int nominee) {
		this.nominee = nominee;
	}

	public int getOwner() {
		return owner;
	}

	public void setOwner(int owner) {
		this.owner = owner;
	}

	public int getPolicy() {
		return policy;
	}

	public void setPolicy(int policy) {
		this.policy = policy;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public Timestamp getTs() {
		return ts;
	}

	public void setTs(Timestamp ts) {
		this.ts = ts;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
