package com.impetus.insurance.app.rest.controller;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.impetus.insurance.app.entity.Admin;
import com.impetus.insurance.app.entity.PasswordEncrypt;
import com.impetus.insurance.app.entity.UnderWriter;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.exceptions.InvalidEmailIdException;
import com.impetus.insurance.app.service.impl.AdminService;
import com.impetus.insurance.app.service.impl.UnderWriterService;
import com.impetus.insurance.app.service.impl.UserService;

/**
 * This rest controller handles all the api calls for validation and
 * authentication.
 * 
 * @author deeksha.patidar
 * @version 1.0
 */
@RestController
@RequestMapping("/api/v1/")
public class ValidationAndAuthenticationController {

	@Autowired
	UserService userService;

	@Autowired
	AdminService adminService;

	@Autowired
	UnderWriterService underwriterService;

	/**
	 * This method is user login api
	 * 
	 * @param object inputs User object
	 * @return User object
	 * @throws InvalidCredentialsException
	 */
	@PostMapping("/users/login")
	public ResponseEntity<User> userLogin(@RequestBody User object) throws InvalidCredentialsException {
		return new ResponseEntity<>(userService.validateLogin(object), HttpStatus.ACCEPTED);
	}

	/**
	 * This method is user signup api
	 * 
	 * @param object inputs User object
	 * @return User object
	 * @throws InvalidEmailIdException 
	 */
	@PostMapping("/users")
	public ResponseEntity<HttpStatus> userSignUp(@RequestBody @Valid User object) throws InvalidEmailIdException {

		object.setAge(User.calculateAgeWithJava7(object.getDob()));
    	object.setPassword(PasswordEncrypt.EncryptPass(object.getPassword())) ;
		userService.createNewAcccount(object);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	/**
	 * This method is admin login api
	 * 
	 * @param object inputs Admin object
	 * @return Admin object
	 * @throws InvalidCredentialsException
	 */
	@PostMapping("/admin/login")
	public ResponseEntity<Admin> adminLogin(@RequestBody Admin object) throws InvalidCredentialsException {
		return new ResponseEntity<>(adminService.validateLogin(object), HttpStatus.ACCEPTED);
	}

	/**
	 * This method is admin signup api
	 * 
	 * @param object inputs Admin object
	 * @return HttpStatus
	 */
	@PostMapping("/admin")
	public ResponseEntity<HttpStatus> adminSignUp(@RequestBody @Valid Admin object) {
		object.setPassword(PasswordEncrypt.EncryptPass(object.getPassword())) ;
		adminService.createNewAcccount(object);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	/**
	 * This method is underwriter login api
	 * 
	 * @param object inputs Underwriter object
	 * @return Underwriter object
	 * @throws InvalidCredentialsException
	 */
	@PostMapping("/underwriter/login")
	public ResponseEntity<UnderWriter> underwriterLogin(@RequestBody UnderWriter object)
			throws InvalidCredentialsException {
		return new ResponseEntity<>(underwriterService.validateLogin(object), HttpStatus.ACCEPTED);
	}

	/**
	 * This method is underwriter signup api
	 * 
	 * @param object inputs Underwriter object
	 * @return HttpStatus
	 */
	@PostMapping("/underwriter")
	public ResponseEntity<HttpStatus> underwriterSignUp(@RequestBody @Valid UnderWriter object) {
		object.setPassword(PasswordEncrypt.EncryptPass(object.getPassword())) ;
		underwriterService.createNewAcccount(object);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
}
