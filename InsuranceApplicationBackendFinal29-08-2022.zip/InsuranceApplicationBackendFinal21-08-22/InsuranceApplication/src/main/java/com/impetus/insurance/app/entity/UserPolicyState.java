package com.impetus.insurance.app.entity;

import java.sql.Timestamp;
import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the UserPolicyState.
 * 
 * @author deeksha.patidar
 *
 */
@Getter
@Setter
@ToString
@Entity
@Table(name = "owned_policy_state")
public class UserPolicyState {

	/**
	 * int value for primary key
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;

	/**
	 * long value for premium
	 */
	@NotNull
	@Column(name = "premium")
	long premium;

	/**
	 * foreign key value for nominee object
	 */
	@NotNull
	@OneToOne
	Nominee nominee;

	/**
	 * foreign key value for user object
	 */
	@NotNull
	@OneToOne
	User owner;

	/**
	 * foreign key value for policy object
	 */
	@NotNull
	@OneToOne
	Policy policy;

	/**
	 * string value for summary
	 */
	String summary;

	/**
	 * Timestamp value
	 */
	@NotNull
	Timestamp ts;

	/**
	 * string value for status
	 */
	@NotNull
	String status;

	/**
	 * Default Constructor
	 */
	public UserPolicyState() {

	}

	/**
	 * Parameterised Constructor
	 * 
	 * @param id
	 * @param premium
	 * @param nominee
	 * @param owner
	 * @param policy
	 * @param summary
	 * @param ts
	 * @param status
	 */
	public UserPolicyState(int id, @NotNull long premium, @NotNull Nominee nominee, @NotNull User owner,
			@NotNull Policy policy, String summary, Timestamp ts, String status) {
		super();
		this.id = id;
		this.premium = premium;
		this.nominee = nominee;
		this.owner = owner;
		this.policy = policy;
		this.summary = summary;
		this.ts = ts;
		this.status = status;
	}

	public void setONominee(Optional<Nominee> nominee) {
		if (nominee.isPresent())
			this.nominee = nominee.get();
	}

	public void setOOwner(Optional<User> owner) {
		if (owner.isPresent())
			this.owner = owner.get();
	}

	public void setOPolicy(Optional<Policy> policy) {
		if (policy.isPresent())
			this.policy = policy.get();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	//-----------------------

	public long getPremium() {
		return premium;
	}

	public void setPremium(long premium) {
		this.premium = premium;
	}

	public Nominee getNominee() {
		return nominee;
	}

	public User getOwner() {
		return owner;
	}
	public Policy getPolicy() {
		return policy;
	}
	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public Timestamp getTs() {
		return ts;
	}

	public void setTs(Timestamp ts) {
		this.ts = ts;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setNominee(Nominee nominee) {
		this.nominee = nominee;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}

	public void setPolicy(Policy policy) {
		this.policy = policy;
	}
	
	
}
