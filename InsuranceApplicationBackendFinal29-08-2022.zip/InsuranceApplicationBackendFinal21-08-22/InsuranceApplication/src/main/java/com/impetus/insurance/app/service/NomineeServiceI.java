package com.impetus.insurance.app.service;

import com.impetus.insurance.app.entity.Nominee;

/**
 * This interface implements NomineeService Interface,it declares the methods.
 * 
 * @author deeksha.patidar
 *
 */
public interface NomineeServiceI {

	/**
	 * This method add new Nominee object and return it or if already present then
	 * returns that object
	 * 
	 * @param object inputs Nominee type object
	 * @return Nominee object
	 */
	public Nominee add(Nominee object);

	/**
	 * This method deletes Nominee object with given id
	 * 
	 * @param id inputs int id
	 */
	public void remove(int id);

	/**
	 * This method returns Nominee object with the given aadharNo
	 * 
	 * @param aadharNo inputs aadharNo
	 * @return Nominee object
	 */
	public Nominee findByAadhar(long aadharNo);
}
