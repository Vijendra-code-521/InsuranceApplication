package com.impetus.insurance.app.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.impetus.insurance.app.entity.UnderWriter;

/**
 * This interface implements UnderWriter Repository Interface
 * @author deeksha.patidar
 *
 */
@Repository
public interface UnderWriterRepository extends CrudRepository<UnderWriter, Integer> {
	
	/**This method returns true or false on checking whether that email exists or not 
	 * @param email inputs string value of email
	 * @return boolean
	 */
	boolean existsByEmail(String email);

	/**This method returns UnderWriter object with that email
	 * @param email inputs string value of email
	 * @return UnderWriter object
	 */
	UnderWriter findByEmail(String email);
}
