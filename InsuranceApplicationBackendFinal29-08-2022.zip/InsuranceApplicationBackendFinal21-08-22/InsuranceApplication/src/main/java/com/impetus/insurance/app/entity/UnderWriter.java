package com.impetus.insurance.app.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the Admin.
 * 
 * @author deeksha.patidar
 *
 */
@Getter
@Setter
@ToString
@Entity
@Table(name = "underwriter")
public class UnderWriter {

	/**
	 * int value for primary key
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;

	/**
	 * string value for email
	 */
	@NotNull
	String email;

	/**
	 * string value for password
	 */
	@NotNull
	String password;

	/**
	 * Default Constructor
	 */
	public UnderWriter() {

	}

	/**
	 * Parameterised Constructor
	 * 
	 * @param email
	 * @param password
	 */
	public UnderWriter(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
