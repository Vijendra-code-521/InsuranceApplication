package com.impetus.insurance.app.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.impetus.insurance.app.entity.Admin;

/**
 * This interface implements Admin Repository Interface
 * @author deeksha.patidar
 *
 */
@Repository
public interface AdminRepository extends CrudRepository<Admin, Integer> {
	
	/**This method returns true or false on checking whether that email exists or not 
	 * @param email inputs string value of email
	 * @return boolean
	 */
	boolean existsByEmail(String email);

	/**This method returns Admin object with that email
	 * @param email inputs string value of email
	 * @return Admin object
	 */
	Admin findByEmail(String email);
}
