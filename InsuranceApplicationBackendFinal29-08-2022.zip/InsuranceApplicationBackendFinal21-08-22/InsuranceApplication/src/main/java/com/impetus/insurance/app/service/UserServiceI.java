package com.impetus.insurance.app.service;

import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.exceptions.InvalidEmailIdException;

/**
 * This interface implements UserService Interface,it declares the methods.
 * 
 * @author deeksha.patidar
 *
 */
public interface UserServiceI {

	/**
	 * This method handles User login
	 * 
	 * @param object inputs User object
	 * @return User object if login is successfull
	 * @throws InvalidCredentialsException
	 */
	public User validateLogin(User object) throws InvalidCredentialsException;

	/**
	 * This method handles User signup
	 * 
	 * @param object inputs User object
	 * @throws InvalidEmailIdException 
	 */
	public void createNewAcccount(User object) throws InvalidEmailIdException;

}
