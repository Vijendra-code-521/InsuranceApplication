package com.impetus.insurance.app.exceptions;


/**
 * Raised when admin tries to delete policy which is already purchased by users.
 * @author deeksha.patidar
 *
 */
public class InvalidPolicyIdException extends Exception{

	private static final long serialVersionUID = 1L;
	
	public InvalidPolicyIdException(String s)
	{
		super(s);
	}
}
