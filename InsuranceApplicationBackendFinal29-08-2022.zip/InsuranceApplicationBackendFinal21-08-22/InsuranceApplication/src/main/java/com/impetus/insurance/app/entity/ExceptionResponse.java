package com.impetus.insurance.app.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the ExceptionResponse for ExceptionHandler.
 * 
 * @author deeksha.patidar
 *
 */

@Getter
@Setter
@ToString
public class ExceptionResponse {

	/**
	 * String value for timestamp
	 */
	String timestamp;
	/**
	 * String value for error
	 */
	String error;
	/**
	 * String value for status
	 */
	String status;
	/**
	 * String value for uri path
	 */
	String path;

	/**
	 * Default Constructor
	 */
	public ExceptionResponse() {
		
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	

}
