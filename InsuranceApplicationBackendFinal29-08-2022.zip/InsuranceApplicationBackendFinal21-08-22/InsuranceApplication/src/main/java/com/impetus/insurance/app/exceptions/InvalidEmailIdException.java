package com.impetus.insurance.app.exceptions;


public class InvalidEmailIdException extends Exception{

	/**
	 * Raised when user tries to register with existing users email.
	 * @author v.vishwakarma
	 */
	private static final long serialVersionUID = 1L;

	public InvalidEmailIdException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidEmailIdException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public InvalidEmailIdException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidEmailIdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidEmailIdException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
