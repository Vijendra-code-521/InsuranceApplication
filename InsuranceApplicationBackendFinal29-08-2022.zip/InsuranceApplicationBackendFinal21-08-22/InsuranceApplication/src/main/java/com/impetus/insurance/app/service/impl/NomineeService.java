package com.impetus.insurance.app.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.impetus.insurance.app.entity.Nominee;
import com.impetus.insurance.app.repository.NomineeRepository;
import com.impetus.insurance.app.service.NomineeServiceI;

/**
 * This class implements Nominee Service
 * @author deeksha.patidar
 *
 */
@Component
public class NomineeService implements NomineeServiceI{

	@Autowired
	NomineeRepository nomineeRepo;

	final Logger logger = LogManager.getLogger(NomineeService.class);
	
	/**This method creates new Nominee
	 *	
	 */
	@Override
	public Nominee add(Nominee object) {
		Nominee responseObject = nomineeRepo.findByAadharNo(object.getAadharNo());
		if(responseObject == null) {
			nomineeRepo.save(object);
			logger.info("Nominee created successsfully.");
		}
		logger.info("Returning existing nominee.");
		return nomineeRepo.findByAadharNo(object.getAadharNo());
	}

	/**
	 *This method removes Nominee with the given id
	 */
	@Override
	public void remove(int id) {
		nomineeRepo.deleteById(id);
		logger.info("Nominee delted successsfully.");
	}

	/**
	 *This method returns Nominee object having given Aadhar number
	 */
	@Override
	public Nominee findByAadhar(long aNo) {
		logger.info("searching for nominee based on Aadhar number.");
		return nomineeRepo.findByAadharNo(aNo);
	}

}
