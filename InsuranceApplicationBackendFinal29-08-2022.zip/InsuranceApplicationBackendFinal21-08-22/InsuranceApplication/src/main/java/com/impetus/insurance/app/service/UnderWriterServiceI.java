package com.impetus.insurance.app.service;

import com.impetus.insurance.app.entity.UnderWriter;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;

/**
 * This interface implements UnderWriterService Interface,it declares the
 * methods.
 * 
 * @author deeksha.patidar
 *
 */
public interface UnderWriterServiceI {

	/**
	 * This method handles UnderWriter login
	 * 
	 * @param object inputs UnderWriter object
	 * @return UnderWriter object if login is successfull
	 * @throws InvalidCredentialsException
	 */
	public UnderWriter validateLogin(UnderWriter object) throws InvalidCredentialsException;

	/**
	 * This method handles UnderWriter signup
	 * 
	 * @param object inputs UnderWriter object
	 */
	public void createNewAcccount(UnderWriter object);
}
