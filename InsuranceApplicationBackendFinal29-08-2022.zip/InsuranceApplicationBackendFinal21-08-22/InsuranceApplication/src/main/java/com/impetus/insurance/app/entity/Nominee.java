package com.impetus.insurance.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class implements the Nominee.
 * 
 * @author deeksha.patidar
 *
 */
@Getter
@Setter
@ToString
@Entity
@Table(name = "nominee")
public class Nominee {

	/**
	 * int value for primary key
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;

	/**
	 * string value for firstName
	 */
	@NotNull
	@Column(name = "first_name")
	String firstName;

	/**
	 * string value for lastName
	 */
	@NotNull
	@Column(name = "last_name")
	String lastName;

	/**
	 * string value for relation with policyholder
	 */
	@NotNull
	String relation;

	/**
	 * long value for aadharNo
	 */
	long aadharNo;

	/**
	 * long value for phone
	 */
	@NotNull
	long phone;

	/**
	 * Default Constructor
	 */
	public Nominee() {

	}

	/**
	 * Parameterised Constructor
	 * 
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param relation
	 * @param aadharNo
	 * @param phone
	 */
	public Nominee(int id, @NotNull String firstName, @NotNull String lastName, @NotNull String relation, long aadharNo,
			@NotNull long phone) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.relation = relation;
		this.aadharNo = aadharNo;
		this.phone = phone;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public long getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(long aadharNo) {
		this.aadharNo = aadharNo;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}
	
}
