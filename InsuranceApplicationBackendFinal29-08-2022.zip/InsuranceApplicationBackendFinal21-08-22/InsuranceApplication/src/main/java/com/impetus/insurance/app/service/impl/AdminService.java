package com.impetus.insurance.app.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.impetus.insurance.app.entity.Admin;
import com.impetus.insurance.app.entity.PasswordEncrypt;
import com.impetus.insurance.app.exceptions.InvalidCredentialsException;
import com.impetus.insurance.app.repository.AdminRepository;
import com.impetus.insurance.app.service.AdminServiceI;

/**
 * This class implements Admin Service
 * @author deeksha.patidar
 *
 */
@Component
public class AdminService implements AdminServiceI {

	@Autowired
	AdminRepository adminRepo;

	final Logger logger = LogManager.getLogger(AdminService.class);
	
	/**
	 * This method validates login of Admin, 
	 * returns that Admin object if login is successful
	 * else InvalidCredentialsException is thrown
	 */
	@Override
	public Admin validateLogin(Admin adminObject) throws InvalidCredentialsException {
		
		if (adminRepo.existsByEmail(adminObject.getEmail())) // if correct email
		{
			Admin object = adminRepo.findByEmail(adminObject.getEmail());
			String checker = PasswordEncrypt.EncryptPass(adminObject.getPassword()) ;
			if (checker.equals(object.getPassword())) {
				logger.info("Login successsfull.");
				return object;
				
			} else {
				logger.error("Invalid password.");
				throw new InvalidCredentialsException("Invalid credentials");
			}
		} else {
			logger.warn("Invalid email.");
			throw new InvalidCredentialsException("Invalid credentials");
		}
	}

	/**This method creates new Admin account
	 *	
	 */
	@Override
	public void createNewAcccount(Admin object) {
		adminRepo.save(object);
		logger.info("Account created successsfully.");
	}
}
