package com.impetus.insurance.app.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.impetus.insurance.app.entity.UserPolicyState;

/**
 * This interface implements UserPolicyState Repository Interface
 * @author deeksha.patidar
 *
 */
@Repository
public interface UserPolicyStateRepository extends CrudRepository<UserPolicyState, Integer>{

	/**This method returns List of UserPolicyState i.e. insurance request all objects with that status
	 * @param status inputs string value of status
	 * @return List of UserPolicyState
	 */
	List<UserPolicyState> findAllByStatus(String status);
	
	/**This method returns List of UserPolicyState i.e. insurance request objects associated with that userId
	 * @param userId inputs int value of userId
	 * @return List of UserPolicyState
	 */
	List<UserPolicyState> findAllByOwnerId(int userId);
	
	/**This method returns List of UserPolicyState i.e. insurance request objects associated with that policyId
	 * @param policyId inputs int value of policyId
	 * @return List of UserPolicyState
	 */
	List<UserPolicyState> findAllByPolicyId(int policyId);
}
