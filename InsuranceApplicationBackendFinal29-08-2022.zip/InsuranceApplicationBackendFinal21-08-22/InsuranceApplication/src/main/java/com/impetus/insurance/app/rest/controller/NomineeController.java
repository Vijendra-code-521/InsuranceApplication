package com.impetus.insurance.app.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.impetus.insurance.app.entity.Nominee;
import com.impetus.insurance.app.service.impl.NomineeService;

/**
 * This rest controller handles all the api calls for nominee.
 * 
 * @author deeksha.patidar
 * @version 1.0
 */
@RestController
@RequestMapping("/api/v1/")
public class NomineeController {

	@Autowired
	NomineeService nomineeService;

	/**
	 * This method is post nominee api, adds new nominee
	 * 
	 * @param object
	 * @return Nominee object
	 */
	@PostMapping("nominee")
	public ResponseEntity<Nominee> addNominee(@RequestBody Nominee object) {
		return new ResponseEntity<>(nomineeService.add(object), HttpStatus.CREATED);
	}

	/**
	 * This method is delete nominee api, deletes a nominee
	 * 
	 * @param id
	 */
	@DeleteMapping("nominee/{id}")
	public void deleteNominee(@PathVariable("id") int id) {
		nomineeService.remove(id);
	}

	/**
	 * This method is get nominee api, gets a nominee by aadharNo
	 * 
	 * @param aadharNo
	 * @return Nominee object
	 */
	@GetMapping("nominee/{aadhar_no}")
	public ResponseEntity<Nominee> getNominee(@PathVariable("aadhar_no") long aadharNo) {
		return new ResponseEntity<>(nomineeService.findByAadhar(aadharNo), HttpStatus.OK);
	}
}
