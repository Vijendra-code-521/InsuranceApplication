package com.impetus.insurance.app.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.impetus.insurance.app.StringConstants;
import com.impetus.insurance.app.entity.User;
import com.impetus.insurance.app.entity.UserPolicyState;
import com.impetus.insurance.app.entity.UserPolicyStateDto;
import com.impetus.insurance.app.repository.NomineeRepository;
import com.impetus.insurance.app.repository.PolicyRepository;
import com.impetus.insurance.app.repository.UserPolicyStateRepository;
import com.impetus.insurance.app.repository.UserRepository;
import com.impetus.insurance.app.service.UserPolicyStateServiceI;

/**
 * This class implements UserPolicyState Service
 * 
 * @author deeksha.patidar
 *
 */
@Component
public class UserPolicyStateService implements UserPolicyStateServiceI {

	final Logger logger = LogManager.getLogger(UserPolicyStateService.class);

	@Autowired
	UserPolicyStateRepository uspRepo;

	@Autowired
	PolicyRepository policyRepo;

	@Autowired
	NomineeRepository nomineeRepo;

	@Autowired
	UserRepository userRepo;

	/**This method works as a scheduler 
	 * It handles the insurance requests and 
	 * checks for the requests for a given specified time of scheduler repeatedly. 
	 * 
	 * It auto approves the insurance request based on the conditions specified in the scheduler. 
	 */
	@Scheduled(initialDelay = 100000, fixedDelay = 120000)
	public void autoApproval() {
		logger.info("---Start Schedular---");
		List<UserPolicyState> listOfRequests = (List<UserPolicyState>) uspRepo.findAll();

		List<UserPolicyState> listOfPendingRequests = listOfRequests.stream()
				.filter(x -> (x.getStatus().equals(StringConstants.PENDING))).collect(Collectors.toList());

		List<UserPolicyState> batchOfUpdateRequests = new ArrayList<>();

		for (UserPolicyState request : listOfPendingRequests) {
			boolean approveFlag = false;
			User obj = null;
			int age = 0;
			Optional<User> fetchedObj = userRepo.findById(request.getOwner().getId());

			if (fetchedObj.isPresent()) {
				obj = fetchedObj.get();
				age = obj.getAge();
			}

			long finalPremium = request.getPremium();
			long income = Long.parseLong(obj.getIncome());

			// underage
			if (age < 18) {
				request.setStatus(StringConstants.AWAITING);
				approveFlag = true;
				logger.info("User is underage.");
			}

			// based on income, final premium and mode of pay
			String summary = request.getSummary();
			int payFor = fetchCoverFor(summary);
			int div1;
			int div2;
			int div3;
			div1 = StringUtils.indexOf(summary, StringConstants.MONTHLY);
			div2 = StringUtils.indexOf(summary, StringConstants.ONETIME);
			div3 = StringUtils.indexOf(summary, StringConstants.YEARLY);

			if (div1 > 0 && ((income / 12) < finalPremium)) {
				request.setStatus(StringConstants.AWAITING);
				approveFlag = true;
				logger.info("Monthly premium is more.");
			}

			if (div2 > 0 || div3 > 0 && ((income) < finalPremium)) {
				request.setStatus(StringConstants.AWAITING);
				approveFlag = true;
				logger.info("Premium is more.");
			}

			if (age + 20 < payFor) {
				request.setStatus(StringConstants.AWAITING);
				approveFlag = true;
				logger.info("User won't be able to pay complete premium in required time.");
			}

			// all conditions passed request is approved
			if (!approveFlag) {
				request.setStatus(StringConstants.APPROVED);
				logger.info("Request is approved.");
			}

			batchOfUpdateRequests.add(request);
		}
		logger.info("Updating policy request states.");
		for (UserPolicyState x : batchOfUpdateRequests) {
			update(x.getId(), x);
		}
		logger.info("---End Schedular---");
	}

	/**This method fetches the value of cover for from the summary of purchased policy.
	 * @param summary
	 * @return int value for cover for years.
	 */
	public int fetchCoverFor(String summary) {
		StringBuilder s = new StringBuilder();

		int cnt = 0;

		for (int i = 0; i < summary.length(); i++) {
			if (cnt == 2) {
				if (s.length() <= 2 && summary.charAt(i) != 'y') {
					boolean flag = Character.isDigit(summary.charAt(i));
					if (flag) {
						s.append(summary.charAt(i));
					}
				} else {
					break;
				}
			} else if (summary.charAt(i) == ':') {
				cnt++;
			}
		}

		return Integer.parseInt(s.toString()); // coverFor
	}

	/**
	 * This method adds new insurance request object.
	 * 
	 **/
	@Override
	public void add(UserPolicyStateDto object) {
		UserPolicyState uspObject = new UserPolicyState();

		uspObject.setONominee(nomineeRepo.findById(object.getNominee()));
		uspObject.setOOwner(userRepo.findById(object.getOwner()));
		uspObject.setOPolicy(policyRepo.findById(object.getPolicy()));
		uspObject.setPremium(object.getPremium());
		uspObject.setSummary(object.getSummary());

		Date date = new Date();
		Timestamp ts = new Timestamp(date.getTime());

		uspObject.setTs(ts);
		uspObject.setStatus(StringConstants.PENDING);

		uspRepo.save(uspObject);
		logger.info("New insurance request added successfully.");
	}

	/**
	 * This method adds new insurance request object.
	 * 
	 **/
	public UserPolicyState viewById(int id) {
		Optional<UserPolicyState> pObject = Optional.ofNullable(uspRepo.findById(id)).get();

		UserPolicyState object = null;
		if (pObject.isPresent()) {
			object = pObject.get();
		}
		logger.info("Returning the requested policy request with given id.");
		return object;
	}

	/**
	 * This method updates the insurance request object with the given id and
	 * returns updated object
	 **/
	public UserPolicyState update(int id, UserPolicyState object) {
		if (viewById(id).getId() == id) {
			uspRepo.save(object);
		}
		logger.info("Insurance request state updated successfull.");
		return object;
	}

	/**
	 * This method returns all the polices that are purchased by the user with the
	 * given userId
	 **/
	public List<UserPolicyState> getMyPolicies(int userId) {
		logger.info("Returning all owned insurance policies by a user.");
		return uspRepo.findAllByOwnerId(userId);
	}

	/**
	 * This method returns all the insurance request objects with the given status
	 **/
	public List<UserPolicyState> getRequestObjectByStatus(String status) {
		logger.info("Fetching insurance request by given status.");
		return uspRepo.findAllByStatus(status);
	}

	/**
	 * This method returns all the existing insurance request objects
	 **/
	public List<UserPolicyState> getAll() {
		logger.info("Fetching all insurance requests.");
		return (List<UserPolicyState>) uspRepo.findAll();
	}

}
